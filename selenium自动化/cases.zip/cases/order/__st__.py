force_tags = [ ]
 

def suite_teardown():
    pass