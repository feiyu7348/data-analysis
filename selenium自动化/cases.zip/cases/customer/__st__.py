force_tags = ['客户功能']

def suite_setup(): 
    pass

def suite_teardown():
    raise Exception('NO ...')
    pass

